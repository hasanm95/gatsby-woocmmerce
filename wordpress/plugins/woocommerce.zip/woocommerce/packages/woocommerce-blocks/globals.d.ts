declare var fetchMock: any;
